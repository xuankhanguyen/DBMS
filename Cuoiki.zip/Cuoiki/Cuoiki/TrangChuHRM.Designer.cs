﻿namespace Cuoiki
{
    partial class TrangChuHRM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrangChuHRM));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.panelRe = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btTT = new System.Windows.Forms.Button();
            this.btRE = new System.Windows.Forms.Button();
            this.panelUp = new System.Windows.Forms.Panel();
            this.btn_NhanVien = new System.Windows.Forms.Button();
            this.bt_1 = new System.Windows.Forms.Button();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.btclose = new System.Windows.Forms.Button();
            this.labelTile = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnHopDong = new System.Windows.Forms.Button();
            this.btnHSLuong = new System.Windows.Forms.Button();
            this.btHT = new System.Windows.Forms.Button();
            this.btDX = new System.Windows.Forms.Button();
            this.panelSYS = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.panelRe.SuspendLayout();
            this.panelUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panelSYS.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1540, 844);
            this.splitContainer1.SplitterDistance = 275;
            this.splitContainer1.SplitterWidth = 8;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.BackColor = System.Drawing.Color.White;
            this.splitContainer3.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.AutoScroll = true;
            this.splitContainer3.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.splitContainer3.Panel2.Controls.Add(this.panelSYS);
            this.splitContainer3.Panel2.Controls.Add(this.btHT);
            this.splitContainer3.Panel2.Controls.Add(this.panelRe);
            this.splitContainer3.Panel2.Controls.Add(this.btRE);
            this.splitContainer3.Panel2.Controls.Add(this.panelUp);
            this.splitContainer3.Panel2.Controls.Add(this.bt_1);
            this.splitContainer3.Size = new System.Drawing.Size(275, 844);
            this.splitContainer3.SplitterDistance = 40;
            this.splitContainer3.SplitterWidth = 8;
            this.splitContainer3.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(275, 40);
            this.label1.TabIndex = 12;
            this.label1.Text = "PROJECT TEAM 03";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelRe
            // 
            this.panelRe.Controls.Add(this.button1);
            this.panelRe.Controls.Add(this.btTT);
            this.panelRe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelRe.Location = new System.Drawing.Point(0, 397);
            this.panelRe.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.panelRe.Name = "panelRe";
            this.panelRe.Size = new System.Drawing.Size(241, 152);
            this.panelRe.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.AliceBlue;
            this.button1.Location = new System.Drawing.Point(0, 75);
            this.button1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(241, 75);
            this.button1.TabIndex = 4;
            this.button1.Text = "Chi tiết bảng công";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btTT
            // 
            this.btTT.Dock = System.Windows.Forms.DockStyle.Top;
            this.btTT.FlatAppearance.BorderSize = 0;
            this.btTT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btTT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btTT.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTT.ForeColor = System.Drawing.Color.AliceBlue;
            this.btTT.Location = new System.Drawing.Point(0, 0);
            this.btTT.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btTT.Name = "btTT";
            this.btTT.Size = new System.Drawing.Size(241, 75);
            this.btTT.TabIndex = 3;
            this.btTT.Text = "Kỳ công";
            this.btTT.UseVisualStyleBackColor = true;
            this.btTT.Click += new System.EventHandler(this.btTT_Click);
            // 
            // btRE
            // 
            this.btRE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.btRE.Dock = System.Windows.Forms.DockStyle.Top;
            this.btRE.FlatAppearance.BorderSize = 0;
            this.btRE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btRE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btRE.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btRE.ForeColor = System.Drawing.Color.AliceBlue;
            this.btRE.Location = new System.Drawing.Point(0, 312);
            this.btRE.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btRE.Name = "btRE";
            this.btRE.Size = new System.Drawing.Size(241, 85);
            this.btRE.TabIndex = 2;
            this.btRE.Text = "Quản lý chấm công";
            this.btRE.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btRE.UseVisualStyleBackColor = false;
            this.btRE.Click += new System.EventHandler(this.btRE_Click);
            // 
            // panelUp
            // 
            this.panelUp.Controls.Add(this.btnHSLuong);
            this.panelUp.Controls.Add(this.btnHopDong);
            this.panelUp.Controls.Add(this.btn_NhanVien);
            this.panelUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUp.Location = new System.Drawing.Point(0, 73);
            this.panelUp.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.panelUp.Name = "panelUp";
            this.panelUp.Size = new System.Drawing.Size(241, 239);
            this.panelUp.TabIndex = 1;
            // 
            // btn_NhanVien
            // 
            this.btn_NhanVien.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_NhanVien.FlatAppearance.BorderSize = 0;
            this.btn_NhanVien.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btn_NhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_NhanVien.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NhanVien.ForeColor = System.Drawing.Color.AliceBlue;
            this.btn_NhanVien.Location = new System.Drawing.Point(0, 0);
            this.btn_NhanVien.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_NhanVien.Name = "btn_NhanVien";
            this.btn_NhanVien.Size = new System.Drawing.Size(241, 87);
            this.btn_NhanVien.TabIndex = 2;
            this.btn_NhanVien.Text = "Thông tin nhân viên";
            this.btn_NhanVien.UseVisualStyleBackColor = true;
            this.btn_NhanVien.Click += new System.EventHandler(this.btn_NhanVien_Click);
            // 
            // bt_1
            // 
            this.bt_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.bt_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.bt_1.FlatAppearance.BorderSize = 0;
            this.bt_1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.bt_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_1.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_1.ForeColor = System.Drawing.Color.AliceBlue;
            this.bt_1.Location = new System.Drawing.Point(0, 0);
            this.bt_1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.bt_1.Name = "bt_1";
            this.bt_1.Size = new System.Drawing.Size(241, 73);
            this.bt_1.TabIndex = 0;
            this.bt_1.Text = "Quản lý nhân sự";
            this.bt_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_1.UseVisualStyleBackColor = false;
            this.bt_1.Click += new System.EventHandler(this.btUp_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.BackColor = System.Drawing.Color.MintCream;
            this.splitContainer2.Panel1.Controls.Add(this.btclose);
            this.splitContainer2.Panel1.Controls.Add(this.labelTile);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("splitContainer2.Panel2.BackgroundImage")));
            this.splitContainer2.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.splitContainer2.Size = new System.Drawing.Size(1257, 844);
            this.splitContainer2.SplitterDistance = 40;
            this.splitContainer2.SplitterWidth = 8;
            this.splitContainer2.TabIndex = 0;
            // 
            // btclose
            // 
            this.btclose.Dock = System.Windows.Forms.DockStyle.Left;
            this.btclose.FlatAppearance.BorderSize = 0;
            this.btclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btclose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btclose.ForeColor = System.Drawing.Color.Red;
            this.btclose.Location = new System.Drawing.Point(0, 0);
            this.btclose.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btclose.Name = "btclose";
            this.btclose.Size = new System.Drawing.Size(154, 40);
            this.btclose.TabIndex = 2;
            this.btclose.Text = "X";
            this.btclose.UseVisualStyleBackColor = true;
            this.btclose.Click += new System.EventHandler(this.btclose_Click);
            // 
            // labelTile
            // 
            this.labelTile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelTile.Font = new System.Drawing.Font("Sitka Text Semibold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTile.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labelTile.Location = new System.Drawing.Point(0, 0);
            this.labelTile.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelTile.Name = "labelTile";
            this.labelTile.Size = new System.Drawing.Size(1257, 40);
            this.labelTile.TabIndex = 0;
            this.labelTile.Text = "HOME";
            this.labelTile.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 20;
            // 
            // btnHopDong
            // 
            this.btnHopDong.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHopDong.FlatAppearance.BorderSize = 0;
            this.btnHopDong.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnHopDong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHopDong.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHopDong.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnHopDong.Location = new System.Drawing.Point(0, 87);
            this.btnHopDong.Margin = new System.Windows.Forms.Padding(6);
            this.btnHopDong.Name = "btnHopDong";
            this.btnHopDong.Size = new System.Drawing.Size(241, 78);
            this.btnHopDong.TabIndex = 3;
            this.btnHopDong.Text = "Hợp đồng";
            this.btnHopDong.UseVisualStyleBackColor = true;
            this.btnHopDong.Click += new System.EventHandler(this.btnHopDong_Click);
            // 
            // btnHSLuong
            // 
            this.btnHSLuong.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHSLuong.FlatAppearance.BorderSize = 0;
            this.btnHSLuong.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnHSLuong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHSLuong.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHSLuong.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnHSLuong.Location = new System.Drawing.Point(0, 165);
            this.btnHSLuong.Margin = new System.Windows.Forms.Padding(6);
            this.btnHSLuong.Name = "btnHSLuong";
            this.btnHSLuong.Size = new System.Drawing.Size(241, 74);
            this.btnHSLuong.TabIndex = 4;
            this.btnHSLuong.Text = "Hệ Số Lương";
            this.btnHSLuong.UseVisualStyleBackColor = true;
            this.btnHSLuong.Click += new System.EventHandler(this.btnHSLuong_Click);
            // 
            // btHT
            // 
            this.btHT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.btHT.Dock = System.Windows.Forms.DockStyle.Top;
            this.btHT.FlatAppearance.BorderSize = 0;
            this.btHT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btHT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHT.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHT.ForeColor = System.Drawing.Color.AliceBlue;
            this.btHT.Location = new System.Drawing.Point(0, 549);
            this.btHT.Margin = new System.Windows.Forms.Padding(6);
            this.btHT.Name = "btHT";
            this.btHT.Size = new System.Drawing.Size(241, 85);
            this.btHT.TabIndex = 4;
            this.btHT.Text = "Quản lý lương";
            this.btHT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btHT.UseVisualStyleBackColor = false;
            this.btHT.Click += new System.EventHandler(this.btHT_Click);
            // 
            // btDX
            // 
            this.btDX.Dock = System.Windows.Forms.DockStyle.Top;
            this.btDX.FlatAppearance.BorderSize = 0;
            this.btDX.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btDX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDX.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDX.ForeColor = System.Drawing.Color.AliceBlue;
            this.btDX.Location = new System.Drawing.Point(0, 0);
            this.btDX.Margin = new System.Windows.Forms.Padding(6);
            this.btDX.Name = "btDX";
            this.btDX.Size = new System.Drawing.Size(241, 63);
            this.btDX.TabIndex = 3;
            this.btDX.Text = "Bảng lương";
            this.btDX.UseVisualStyleBackColor = true;
            this.btDX.Click += new System.EventHandler(this.buttonbangluong_Click);
            // 
            // panelSYS
            // 
            this.panelSYS.Controls.Add(this.button3);
            this.panelSYS.Controls.Add(this.button2);
            this.panelSYS.Controls.Add(this.btDX);
            this.panelSYS.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSYS.Location = new System.Drawing.Point(0, 634);
            this.panelSYS.Margin = new System.Windows.Forms.Padding(6);
            this.panelSYS.Name = "panelSYS";
            this.panelSYS.Size = new System.Drawing.Size(241, 212);
            this.panelSYS.TabIndex = 5;
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.AliceBlue;
            this.button2.Location = new System.Drawing.Point(0, 63);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(241, 63);
            this.button2.TabIndex = 4;
            this.button2.Text = "Ứng lương";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.buttonungluong_Click);
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Sitka Text Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.AliceBlue;
            this.button3.Location = new System.Drawing.Point(0, 126);
            this.button3.Margin = new System.Windows.Forms.Padding(6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(241, 63);
            this.button3.TabIndex = 5;
            this.button3.Text = "Tăng ca";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.buttontangca_Click);
            // 
            // TrangChuHRM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(1540, 844);
            this.Controls.Add(this.splitContainer1);
            this.ForeColor = System.Drawing.Color.SteelBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "TrangChuHRM";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trang Chủ HRM";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.TrangChuHRM_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.panelRe.ResumeLayout(false);
            this.panelUp.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panelSYS.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Panel panelRe;
        private System.Windows.Forms.Button btRE;
        private System.Windows.Forms.Panel panelUp;
        private System.Windows.Forms.Button btn_NhanVien;
        private System.Windows.Forms.Button bt_1;
        private System.Windows.Forms.Label labelTile;
        private System.Windows.Forms.Button btclose;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btTT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnHSLuong;
        private System.Windows.Forms.Button btnHopDong;
        private System.Windows.Forms.Panel panelSYS;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btDX;
        private System.Windows.Forms.Button btHT;
    }
}