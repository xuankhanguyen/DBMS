﻿namespace Cuoiki
{
    partial class FormChuongTrinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMenu = new System.Windows.Forms.Panel();
            this.bt4 = new System.Windows.Forms.Button();
            this.btPhongBan = new System.Windows.Forms.Button();
            this.btDangXuat = new System.Windows.Forms.Button();
            this.bt3 = new System.Windows.Forms.Button();
            this.bt2 = new System.Windows.Forms.Button();
            this.btLoaiTangCa = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.lbNhom = new System.Windows.Forms.Label();
            this.panelTitleBar = new System.Windows.Forms.Panel();
            this.btMaxMinSize = new System.Windows.Forms.Button();
            this.btMiniSize = new System.Windows.Forms.Button();
            this.btClose = new System.Windows.Forms.Button();
            this.btCloseChildForm = new System.Windows.Forms.Button();
            this.lbTitle = new System.Windows.Forms.Label();
            this.panelDesktopPane = new System.Windows.Forms.Panel();
            this.panelMenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            this.panelTitleBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panelMenu.Controls.Add(this.bt4);
            this.panelMenu.Controls.Add(this.btPhongBan);
            this.panelMenu.Controls.Add(this.btDangXuat);
            this.panelMenu.Controls.Add(this.bt3);
            this.panelMenu.Controls.Add(this.bt2);
            this.panelMenu.Controls.Add(this.btLoaiTangCa);
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(220, 518);
            this.panelMenu.TabIndex = 0;
            this.panelMenu.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelMenu_MouseDown);
            // 
            // bt4
            // 
            this.bt4.FlatAppearance.BorderSize = 0;
            this.bt4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt4.ForeColor = System.Drawing.Color.Gainsboro;
            this.bt4.Location = new System.Drawing.Point(-6, 267);
            this.bt4.Name = "bt4";
            this.bt4.Size = new System.Drawing.Size(220, 55);
            this.bt4.TabIndex = 7;
            this.bt4.Text = "Phân Quyền";
            this.bt4.UseVisualStyleBackColor = true;
            this.bt4.Click += new System.EventHandler(this.bt4_Click);
            // 
            // btPhongBan
            // 
            this.btPhongBan.FlatAppearance.BorderSize = 0;
            this.btPhongBan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPhongBan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPhongBan.ForeColor = System.Drawing.Color.Gainsboro;
            this.btPhongBan.Location = new System.Drawing.Point(0, 328);
            this.btPhongBan.Name = "btPhongBan";
            this.btPhongBan.Size = new System.Drawing.Size(220, 55);
            this.btPhongBan.TabIndex = 6;
            this.btPhongBan.Text = "Phòng ban";
            this.btPhongBan.UseVisualStyleBackColor = true;
            this.btPhongBan.Click += new System.EventHandler(this.btPhongBan_Click);
            // 
            // btDangXuat
            // 
            this.btDangXuat.FlatAppearance.BorderSize = 0;
            this.btDangXuat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDangXuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDangXuat.ForeColor = System.Drawing.Color.Gainsboro;
            this.btDangXuat.Location = new System.Drawing.Point(0, 389);
            this.btDangXuat.Name = "btDangXuat";
            this.btDangXuat.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btDangXuat.Size = new System.Drawing.Size(220, 55);
            this.btDangXuat.TabIndex = 5;
            this.btDangXuat.Text = "Đăng Xuất";
            this.btDangXuat.UseVisualStyleBackColor = true;
            this.btDangXuat.Click += new System.EventHandler(this.btDangXuat_Click);
            // 
            // bt3
            // 
            this.bt3.FlatAppearance.BorderSize = 0;
            this.bt3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt3.ForeColor = System.Drawing.Color.Gainsboro;
            this.bt3.Location = new System.Drawing.Point(0, 206);
            this.bt3.Name = "bt3";
            this.bt3.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.bt3.Size = new System.Drawing.Size(220, 55);
            this.bt3.TabIndex = 3;
            this.bt3.Text = "Tài Khoản";
            this.bt3.UseVisualStyleBackColor = true;
            this.bt3.Click += new System.EventHandler(this.bt3_Click);
            // 
            // bt2
            // 
            this.bt2.FlatAppearance.BorderSize = 0;
            this.bt2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt2.ForeColor = System.Drawing.Color.Gainsboro;
            this.bt2.Location = new System.Drawing.Point(0, 149);
            this.bt2.Name = "bt2";
            this.bt2.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.bt2.Size = new System.Drawing.Size(220, 55);
            this.bt2.TabIndex = 2;
            this.bt2.Text = "Chức vụ";
            this.bt2.UseVisualStyleBackColor = true;
            this.bt2.Click += new System.EventHandler(this.bt2_Click);
            // 
            // btLoaiTangCa
            // 
            this.btLoaiTangCa.FlatAppearance.BorderSize = 0;
            this.btLoaiTangCa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btLoaiTangCa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLoaiTangCa.ForeColor = System.Drawing.Color.Gainsboro;
            this.btLoaiTangCa.Location = new System.Drawing.Point(0, 88);
            this.btLoaiTangCa.Name = "btLoaiTangCa";
            this.btLoaiTangCa.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btLoaiTangCa.Size = new System.Drawing.Size(220, 55);
            this.btLoaiTangCa.TabIndex = 1;
            this.btLoaiTangCa.Text = "Loại tăng ca";
            this.btLoaiTangCa.UseVisualStyleBackColor = true;
            this.btLoaiTangCa.Click += new System.EventHandler(this.bt1_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.panelLogo.Controls.Add(this.lbNhom);
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(220, 83);
            this.panelLogo.TabIndex = 1;
            this.panelLogo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelLogo_MouseDown);
            // 
            // lbNhom
            // 
            this.lbNhom.AutoSize = true;
            this.lbNhom.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNhom.ForeColor = System.Drawing.SystemColors.Control;
            this.lbNhom.Location = new System.Drawing.Point(46, 23);
            this.lbNhom.Name = "lbNhom";
            this.lbNhom.Size = new System.Drawing.Size(102, 29);
            this.lbNhom.TabIndex = 2;
            this.lbNhom.Text = "Nhóm 3";
            this.lbNhom.Click += new System.EventHandler(this.lbNhom_Click);
            // 
            // panelTitleBar
            // 
            this.panelTitleBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.panelTitleBar.Controls.Add(this.btMaxMinSize);
            this.panelTitleBar.Controls.Add(this.btMiniSize);
            this.panelTitleBar.Controls.Add(this.btClose);
            this.panelTitleBar.Controls.Add(this.btCloseChildForm);
            this.panelTitleBar.Controls.Add(this.lbTitle);
            this.panelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitleBar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panelTitleBar.Location = new System.Drawing.Point(220, 0);
            this.panelTitleBar.Name = "panelTitleBar";
            this.panelTitleBar.Size = new System.Drawing.Size(815, 80);
            this.panelTitleBar.TabIndex = 1;
            this.panelTitleBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelTitleBar_MouseDown);
            // 
            // btMaxMinSize
            // 
            this.btMaxMinSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btMaxMinSize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btMaxMinSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btMaxMinSize.ForeColor = System.Drawing.SystemColors.Control;
            this.btMaxMinSize.Location = new System.Drawing.Point(749, 0);
            this.btMaxMinSize.Name = "btMaxMinSize";
            this.btMaxMinSize.Size = new System.Drawing.Size(30, 30);
            this.btMaxMinSize.TabIndex = 4;
            this.btMaxMinSize.Text = "O";
            this.btMaxMinSize.UseVisualStyleBackColor = true;
            this.btMaxMinSize.Click += new System.EventHandler(this.btMaxMinSize_Click);
            // 
            // btMiniSize
            // 
            this.btMiniSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btMiniSize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btMiniSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btMiniSize.ForeColor = System.Drawing.SystemColors.Control;
            this.btMiniSize.Location = new System.Drawing.Point(713, 0);
            this.btMiniSize.Name = "btMiniSize";
            this.btMiniSize.Size = new System.Drawing.Size(30, 30);
            this.btMiniSize.TabIndex = 3;
            this.btMiniSize.Text = "-";
            this.btMiniSize.UseVisualStyleBackColor = true;
            this.btMiniSize.Click += new System.EventHandler(this.btMiniSize_Click);
            // 
            // btClose
            // 
            this.btClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClose.ForeColor = System.Drawing.SystemColors.Control;
            this.btClose.Location = new System.Drawing.Point(785, 0);
            this.btClose.Name = "btClose";
            this.btClose.Size = new System.Drawing.Size(30, 30);
            this.btClose.TabIndex = 2;
            this.btClose.Text = "X";
            this.btClose.UseVisualStyleBackColor = true;
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // btCloseChildForm
            // 
            this.btCloseChildForm.Dock = System.Windows.Forms.DockStyle.Left;
            this.btCloseChildForm.FlatAppearance.BorderSize = 0;
            this.btCloseChildForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCloseChildForm.Image = global::Cuoiki.Properties.Resources.icons8_Close_40px;
            this.btCloseChildForm.Location = new System.Drawing.Point(0, 0);
            this.btCloseChildForm.Name = "btCloseChildForm";
            this.btCloseChildForm.Size = new System.Drawing.Size(80, 80);
            this.btCloseChildForm.TabIndex = 1;
            this.btCloseChildForm.UseVisualStyleBackColor = true;
            this.btCloseChildForm.Click += new System.EventHandler(this.btCloseChildForm_Click);
            // 
            // lbTitle
            // 
            this.lbTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbTitle.AutoSize = true;
            this.lbTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbTitle.Location = new System.Drawing.Point(366, 23);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(88, 29);
            this.lbTitle.TabIndex = 0;
            this.lbTitle.Text = "HOME";
            this.lbTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelDesktopPane
            // 
            this.panelDesktopPane.BackgroundImage = global::Cuoiki.Properties.Resources.Hinh_nen_vu_tru;
            this.panelDesktopPane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesktopPane.Location = new System.Drawing.Point(220, 80);
            this.panelDesktopPane.Name = "panelDesktopPane";
            this.panelDesktopPane.Size = new System.Drawing.Size(815, 438);
            this.panelDesktopPane.TabIndex = 2;
            this.panelDesktopPane.Paint += new System.Windows.Forms.PaintEventHandler(this.panelDesktopPane_Paint);
            this.panelDesktopPane.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelDesktopPane_MouseDown);
            // 
            // FormChuongTrinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1035, 518);
            this.Controls.Add(this.panelDesktopPane);
            this.Controls.Add(this.panelTitleBar);
            this.Controls.Add(this.panelMenu);
            this.Name = "FormChuongTrinh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormChuongTrinh_FormClosed);
            this.Load += new System.EventHandler(this.FormChuongTrinh_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            this.panelLogo.PerformLayout();
            this.panelTitleBar.ResumeLayout(false);
            this.panelTitleBar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button btLoaiTangCa;
        private System.Windows.Forms.Button btDangXuat;
        private System.Windows.Forms.Button bt3;
        private System.Windows.Forms.Button bt2;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Panel panelTitleBar;
        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.Label lbNhom;
        private System.Windows.Forms.Panel panelDesktopPane;
        private System.Windows.Forms.Button btPhongBan;
        private System.Windows.Forms.Button bt4;
        private System.Windows.Forms.Button btCloseChildForm;
        private System.Windows.Forms.Button btClose;
        private System.Windows.Forms.Button btMaxMinSize;
        private System.Windows.Forms.Button btMiniSize;
    }
}
