﻿namespace Cuoiki
{
    partial class UngLuong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonXoaUngLuong = new System.Windows.Forms.Button();
            this.textBoxIDUngLuong = new System.Windows.Forms.TextBox();
            this.labelIDTangCa = new System.Windows.Forms.Label();
            this.buttonSuaUngLuong = new System.Windows.Forms.Button();
            this.buttonThemUngLuong = new System.Windows.Forms.Button();
            this.textBoxNhanVien = new System.Windows.Forms.TextBox();
            this.textBoxGhiChu = new System.Windows.Forms.TextBox();
            this.textBoxTrangthaixoa = new System.Windows.Forms.TextBox();
            this.textBoxSotienungluong = new System.Windows.Forms.TextBox();
            this.textBoxNgayUngLuong = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listViewUngLuong = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.textBoxNam = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxThang = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonLuu = new System.Windows.Forms.Button();
            this.buttonHuy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonXoaUngLuong
            // 
            this.buttonXoaUngLuong.BackColor = System.Drawing.Color.IndianRed;
            this.buttonXoaUngLuong.Location = new System.Drawing.Point(1120, 825);
            this.buttonXoaUngLuong.Name = "buttonXoaUngLuong";
            this.buttonXoaUngLuong.Size = new System.Drawing.Size(148, 68);
            this.buttonXoaUngLuong.TabIndex = 31;
            this.buttonXoaUngLuong.Text = "Xóa Ứng Lương";
            this.buttonXoaUngLuong.UseVisualStyleBackColor = false;
            this.buttonXoaUngLuong.Click += new System.EventHandler(this.buttonXoaUngLuong_Click);
            // 
            // textBoxIDUngLuong
            // 
            this.textBoxIDUngLuong.Location = new System.Drawing.Point(1267, 112);
            this.textBoxIDUngLuong.Name = "textBoxIDUngLuong";
            this.textBoxIDUngLuong.ReadOnly = true;
            this.textBoxIDUngLuong.Size = new System.Drawing.Size(238, 31);
            this.textBoxIDUngLuong.TabIndex = 30;
            // 
            // labelIDTangCa
            // 
            this.labelIDTangCa.AutoSize = true;
            this.labelIDTangCa.Location = new System.Drawing.Point(1111, 112);
            this.labelIDTangCa.Name = "labelIDTangCa";
            this.labelIDTangCa.Size = new System.Drawing.Size(143, 25);
            this.labelIDTangCa.TabIndex = 29;
            this.labelIDTangCa.Text = "ID Ứng Lương";
            // 
            // buttonSuaUngLuong
            // 
            this.buttonSuaUngLuong.BackColor = System.Drawing.Color.IndianRed;
            this.buttonSuaUngLuong.Location = new System.Drawing.Point(1361, 739);
            this.buttonSuaUngLuong.Name = "buttonSuaUngLuong";
            this.buttonSuaUngLuong.Size = new System.Drawing.Size(148, 68);
            this.buttonSuaUngLuong.TabIndex = 28;
            this.buttonSuaUngLuong.Text = "Sửa Ứng Lương";
            this.buttonSuaUngLuong.UseVisualStyleBackColor = false;
            this.buttonSuaUngLuong.Click += new System.EventHandler(this.buttonSuaUngLuong_Click);
            // 
            // buttonThemUngLuong
            // 
            this.buttonThemUngLuong.BackColor = System.Drawing.Color.IndianRed;
            this.buttonThemUngLuong.Location = new System.Drawing.Point(1126, 739);
            this.buttonThemUngLuong.Name = "buttonThemUngLuong";
            this.buttonThemUngLuong.Size = new System.Drawing.Size(148, 68);
            this.buttonThemUngLuong.TabIndex = 27;
            this.buttonThemUngLuong.Text = "Thêm Ứng Lương";
            this.buttonThemUngLuong.UseVisualStyleBackColor = false;
            this.buttonThemUngLuong.Click += new System.EventHandler(this.buttonThemUngLuong_Click);
            // 
            // textBoxNhanVien
            // 
            this.textBoxNhanVien.Location = new System.Drawing.Point(1271, 579);
            this.textBoxNhanVien.Name = "textBoxNhanVien";
            this.textBoxNhanVien.Size = new System.Drawing.Size(238, 31);
            this.textBoxNhanVien.TabIndex = 26;
            // 
            // textBoxGhiChu
            // 
            this.textBoxGhiChu.Location = new System.Drawing.Point(1271, 505);
            this.textBoxGhiChu.Name = "textBoxGhiChu";
            this.textBoxGhiChu.Size = new System.Drawing.Size(238, 31);
            this.textBoxGhiChu.TabIndex = 25;
            // 
            // textBoxTrangthaixoa
            // 
            this.textBoxTrangthaixoa.Location = new System.Drawing.Point(1271, 391);
            this.textBoxTrangthaixoa.Name = "textBoxTrangthaixoa";
            this.textBoxTrangthaixoa.ReadOnly = true;
            this.textBoxTrangthaixoa.Size = new System.Drawing.Size(238, 31);
            this.textBoxTrangthaixoa.TabIndex = 24;
            // 
            // textBoxSotienungluong
            // 
            this.textBoxSotienungluong.Location = new System.Drawing.Point(1271, 290);
            this.textBoxSotienungluong.Name = "textBoxSotienungluong";
            this.textBoxSotienungluong.Size = new System.Drawing.Size(238, 31);
            this.textBoxSotienungluong.TabIndex = 23;
            // 
            // textBoxNgayUngLuong
            // 
            this.textBoxNgayUngLuong.Location = new System.Drawing.Point(1271, 184);
            this.textBoxNgayUngLuong.Name = "textBoxNgayUngLuong";
            this.textBoxNgayUngLuong.Size = new System.Drawing.Size(238, 31);
            this.textBoxNgayUngLuong.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1115, 505);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 25);
            this.label5.TabIndex = 21;
            this.label5.Text = "Ghi Chú";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1115, 579);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 25);
            this.label4.TabIndex = 20;
            this.label4.Text = "Nhân Viên";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1092, 391);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(160, 25);
            this.label3.TabIndex = 19;
            this.label3.Text = "Trạng Thái Xóa";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1077, 293);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 25);
            this.label2.TabIndex = 18;
            this.label2.Text = "Số Tiền Ứng Lương";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1092, 190);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 25);
            this.label1.TabIndex = 17;
            this.label1.Text = "Ngày Ứng Lương";
            // 
            // listViewUngLuong
            // 
            this.listViewUngLuong.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.listViewUngLuong.FullRowSelect = true;
            this.listViewUngLuong.GridLines = true;
            this.listViewUngLuong.HideSelection = false;
            this.listViewUngLuong.Location = new System.Drawing.Point(109, 89);
            this.listViewUngLuong.Name = "listViewUngLuong";
            this.listViewUngLuong.Size = new System.Drawing.Size(958, 675);
            this.listViewUngLuong.TabIndex = 16;
            this.listViewUngLuong.UseCompatibleStateImageBehavior = false;
            this.listViewUngLuong.View = System.Windows.Forms.View.Details;
            this.listViewUngLuong.SelectedIndexChanged += new System.EventHandler(this.listViewUngLuong_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID Ứng Lương";
            this.columnHeader1.Width = 70;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = " Ngày Ứng Lương ";
            this.columnHeader2.Width = 70;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Số Tiền Ứng Lương";
            this.columnHeader3.Width = 70;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Trạng Thái Xóa";
            this.columnHeader4.Width = 70;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Ghi Chú";
            this.columnHeader5.Width = 70;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Nhân Viên Ứng Lương";
            this.columnHeader6.Width = 70;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Kỳ Công Năm";
            this.columnHeader7.Width = 70;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Kỳ Công Tháng";
            this.columnHeader8.Width = 70;
            // 
            // textBoxNam
            // 
            this.textBoxNam.Location = new System.Drawing.Point(1271, 635);
            this.textBoxNam.Name = "textBoxNam";
            this.textBoxNam.Size = new System.Drawing.Size(238, 31);
            this.textBoxNam.TabIndex = 33;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1111, 635);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 25);
            this.label6.TabIndex = 32;
            this.label6.Text = "Kỳ Công Năm";
            // 
            // textBoxThang
            // 
            this.textBoxThang.Location = new System.Drawing.Point(1267, 691);
            this.textBoxThang.Name = "textBoxThang";
            this.textBoxThang.Size = new System.Drawing.Size(238, 31);
            this.textBoxThang.TabIndex = 35;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1100, 694);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(161, 25);
            this.label7.TabIndex = 34;
            this.label7.Text = "Kỳ Công Tháng";
            // 
            // buttonLuu
            // 
            this.buttonLuu.BackColor = System.Drawing.Color.IndianRed;
            this.buttonLuu.Location = new System.Drawing.Point(1303, 825);
            this.buttonLuu.Name = "buttonLuu";
            this.buttonLuu.Size = new System.Drawing.Size(148, 68);
            this.buttonLuu.TabIndex = 37;
            this.buttonLuu.Text = "Lưu Xóa";
            this.buttonLuu.UseVisualStyleBackColor = false;
            this.buttonLuu.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonHuy
            // 
            this.buttonHuy.BackColor = System.Drawing.Color.IndianRed;
            this.buttonHuy.Location = new System.Drawing.Point(1487, 825);
            this.buttonHuy.Name = "buttonHuy";
            this.buttonHuy.Size = new System.Drawing.Size(148, 68);
            this.buttonHuy.TabIndex = 36;
            this.buttonHuy.Text = "Hủy Xóa";
            this.buttonHuy.UseVisualStyleBackColor = false;
            this.buttonHuy.Click += new System.EventHandler(this.buttonHuy_Click);
            // 
            // UngLuong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1744, 930);
            this.Controls.Add(this.buttonLuu);
            this.Controls.Add(this.buttonHuy);
            this.Controls.Add(this.textBoxThang);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxNam);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttonXoaUngLuong);
            this.Controls.Add(this.textBoxIDUngLuong);
            this.Controls.Add(this.labelIDTangCa);
            this.Controls.Add(this.buttonSuaUngLuong);
            this.Controls.Add(this.buttonThemUngLuong);
            this.Controls.Add(this.textBoxNhanVien);
            this.Controls.Add(this.textBoxGhiChu);
            this.Controls.Add(this.textBoxTrangthaixoa);
            this.Controls.Add(this.textBoxSotienungluong);
            this.Controls.Add(this.textBoxNgayUngLuong);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listViewUngLuong);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "UngLuong";
            this.Text = "UngLuong";
            this.Load += new System.EventHandler(this.UngLuong_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonXoaUngLuong;
        private System.Windows.Forms.TextBox textBoxIDUngLuong;
        private System.Windows.Forms.Label labelIDTangCa;
        private System.Windows.Forms.Button buttonSuaUngLuong;
        private System.Windows.Forms.Button buttonThemUngLuong;
        private System.Windows.Forms.TextBox textBoxNhanVien;
        private System.Windows.Forms.TextBox textBoxGhiChu;
        private System.Windows.Forms.TextBox textBoxTrangthaixoa;
        private System.Windows.Forms.TextBox textBoxSotienungluong;
        private System.Windows.Forms.TextBox textBoxNgayUngLuong;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listViewUngLuong;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.TextBox textBoxNam;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxThang;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonLuu;
        private System.Windows.Forms.Button buttonHuy;
    }
}